# VenterApp

Aplicacion de inventario y ventas. Esta guia describe el alcance que esta
implementado en el codigo fuente actual.

## Tecnologias y persistencia

- Java 25 y Spring Boot 3.5.14.
- Spring Web, Spring Validation y Spring Data JPA.
- MySQL mediante MySQL Connector/J; la configuracion local usa la base de
  datos `venterapp_db`.
- Entidades JPA: `Producto`, `Usuario` y `Venta`. Una venta referencia un
  producto; los repositorios usan `JpaRepository`.

## API REST

Los endpoints requieren autenticacion HTTP Basic. En desarrollo, Spring
Security crea el usuario `user` y muestra su contrasena temporal en la consola
al iniciar. Configura credenciales propias antes de publicar la aplicacion.

| Metodo | Ruta | Resultado |
| --- | --- | --- |
| GET | `/api/productos` | Lista productos |
| GET | `/api/productos/{id}` | Consulta un producto |
| POST | `/api/productos` | Crea un producto |
| PUT | `/api/productos/{id}` | Actualiza un producto |
| DELETE | `/api/productos/{id}` | Elimina un producto sin ventas asociadas |
| GET | `/api/ventas` | Lista ventas |
| GET | `/api/ventas/{id}` | Consulta una venta |
| POST | `/api/ventas` | Registra una venta |
| PUT | `/api/ventas/{id}` | Actualiza una venta |
| DELETE | `/api/ventas/{id}` | Elimina una venta |

Las ventas descuentan unidades del producto en la misma transaccion. Una
cantidad superior al stock disponible devuelve `409 Conflict`; editar una
venta revierte el descuento anterior antes de aplicar el nuevo, y eliminarla
devuelve las unidades. No se permite eliminar un producto con ventas asociadas.
Los errores de validacion devuelven `400 Bad Request` y recursos inexistentes
devuelven `404 Not Found`.

Ejemplo de creacion de producto:

```json
{
  "nombre": "Cafe",
  "categoria": "Bebidas",
  "precio": 2.5,
  "cantidadStock": 10
}
```

Ejemplo de creacion de venta:

```json
{
  "cantidadVendida": 2,
  "totalVenta": 5.00,
  "fechaVenta": "2026-11-16T09:00:00",
  "productoId": 1
}
```

`totalVenta` lo proporciona quien llama la API; el servidor valida que sea
positivo y respete la precision de la columna, pero no lo recalcula a partir
del precio del producto.

Para una base ya creada, `src/main/resources/db/maintenance/align-entity-nullability.sql`
contiene el ajuste de esquema correspondiente a las restricciones JPA. Antes
de ejecutarlo en otra instalacion, confirme que las columnas afectadas no
contengan valores nulos.

## Configuracion local

Se requiere JDK 25 y una instancia compatible con MySQL. La aplicacion lee
`DB_USERNAME` y `DB_PASSWORD`; los valores predeterminados del archivo de
configuracion son solo para desarrollo local y no se deben reutilizar en
entornos compartidos o de produccion. La propiedad JPA `ddl-auto=update` puede
ajustar el esquema al iniciar la aplicacion.

En Windows, ejecute las pruebas con:

```powershell
.\mvnw.cmd test
```

Las pruebas HTTP usan una base H2 temporal; no crean ni modifican registros en
la base MySQL/MariaDB configurada para la aplicacion.

## Convenciones de codigo

El codigo Java sigue Google Java Style: dos espacios de indentacion, imports
explicitos, llaves en la misma linea y nombres descriptivos en camelCase. La
configuracion de `.editorconfig` aplica formato de texto consistente. Las
clases de dominio, persistencia y pruebas incluyen JavaDoc conciso sobre su
responsabilidad.

## Artefactos de diseno y control de versiones

La relacion entre las entidades esta representada por las anotaciones JPA del
codigo. No se encontraron historias de usuario, diagramas de casos de uso,
prototipos ni un plan tecnico previo en el workspace revisado; por tanto, el
alcance documentado aqui se limita a las clases existentes y no inventa
requisitos funcionales que no esten respaldados por esos artefactos.

Este directorio es la raiz del repositorio Git del proyecto. No se deben
versionar `target`, archivos `.env`, ni credenciales.
