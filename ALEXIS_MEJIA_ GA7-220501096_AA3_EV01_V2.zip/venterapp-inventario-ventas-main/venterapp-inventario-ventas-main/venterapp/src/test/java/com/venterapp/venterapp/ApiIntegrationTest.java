package com.venterapp.venterapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.venterapp.dto.ApiError;
import com.venterapp.dto.ProductoRequest;
import com.venterapp.dto.ProductoResponse;
import com.venterapp.dto.VentaRequest;
import com.venterapp.dto.VentaResponse;
import com.venterapp.repository.ProductoRepository;
import com.venterapp.repository.VentaRepository;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/** Comprueba los flujos HTTP de productos, ventas y actualizacion del inventario. */
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    properties = {
      "spring.datasource.url=jdbc:h2:mem:venterapp-api;DB_CLOSE_DELAY=-1",
      "spring.datasource.driver-class-name=org.h2.Driver",
      "spring.datasource.username=sa",
      "spring.datasource.password=",
      "spring.jpa.hibernate.ddl-auto=create-drop",
      "spring.jpa.show-sql=false",
      "spring.security.user.name=api-test",
      "spring.security.user.password={noop}api-test-password"
    })
class ApiIntegrationTest {

  @LocalServerPort private int port;

  @Autowired private TestRestTemplate restTemplate;

  @Autowired private ProductoRepository productoRepository;

  @Autowired private VentaRepository ventaRepository;

  @BeforeEach
  void clearDatabase() {
    ventaRepository.deleteAll();
    productoRepository.deleteAll();
  }

  @Test
  void supportsProductCrud() {
    ResponseEntity<ProductoResponse> creation =
        client()
            .postForEntity(
                url("/api/productos"),
                new ProductoRequest("Cafe", "Bebidas", 2.5, 5),
                ProductoResponse.class);

    assertEquals(HttpStatus.CREATED, creation.getStatusCode());
    ProductoResponse created = creation.getBody();
    assertNotNull(created);

    ResponseEntity<ProductoResponse> lookup =
        client().getForEntity(url("/api/productos/" + created.id()), ProductoResponse.class);
    assertEquals(HttpStatus.OK, lookup.getStatusCode());
    assertEquals("Cafe", lookup.getBody().nombre());

    ResponseEntity<ProductoResponse[]> listing =
        client().getForEntity(url("/api/productos"), ProductoResponse[].class);
    assertEquals(HttpStatus.OK, listing.getStatusCode());
    assertEquals(1, listing.getBody().length);

    ResponseEntity<ProductoResponse> update =
        client()
            .exchange(
                url("/api/productos/" + created.id()),
                HttpMethod.PUT,
                new HttpEntity<>(new ProductoRequest("Cafe molido", "Bebidas", 3.0, 7)),
                ProductoResponse.class);
    assertEquals(HttpStatus.OK, update.getStatusCode());
    assertEquals("Cafe molido", update.getBody().nombre());
    assertEquals(7, update.getBody().cantidadStock());

    ResponseEntity<Void> deletion =
        client().exchange(
            url("/api/productos/" + created.id()), HttpMethod.DELETE, HttpEntity.EMPTY, Void.class);
    assertEquals(HttpStatus.NO_CONTENT, deletion.getStatusCode());
    assertEquals(
        HttpStatus.NOT_FOUND,
        client()
            .getForEntity(url("/api/productos/" + created.id()), ApiError.class)
            .getStatusCode());
  }

  @Test
  void protectsApiAndRejectsInvalidProductData() {
    ResponseEntity<String> unauthorized =
        restTemplate.getForEntity(url("/api/productos"), String.class);
    assertEquals(HttpStatus.UNAUTHORIZED, unauthorized.getStatusCode());

    ResponseEntity<String> invalidProduct =
        client()
            .postForEntity(
                url("/api/productos"),
                new ProductoRequest("", "", -1.0, -1),
                String.class);
    assertEquals(HttpStatus.BAD_REQUEST, invalidProduct.getStatusCode());
    assertEquals(0, productoRepository.count());
  }

  @Test
  void saleCrudAdjustsStockAndRejectsOverselling() {
    ProductoResponse product = createProduct("Arroz", 5);
    ProductoResponse otherProduct = createProduct("Frijol", 6);
    VentaRequest saleRequest =
        new VentaRequest(2, new BigDecimal("20.00"), LocalDateTime.now(), product.id());
    ResponseEntity<VentaResponse> creation =
        client().postForEntity(url("/api/ventas"), saleRequest, VentaResponse.class);

    assertEquals(HttpStatus.CREATED, creation.getStatusCode());
    VentaResponse created = creation.getBody();
    assertNotNull(created);
    assertEquals(product.id(), created.productoId());
    assertEquals(3, getProduct(product.id()).cantidadStock());

    ResponseEntity<VentaResponse> lookup =
        client().getForEntity(url("/api/ventas/" + created.id()), VentaResponse.class);
    assertEquals(HttpStatus.OK, lookup.getStatusCode());

    ResponseEntity<VentaResponse[]> listing =
        client().getForEntity(url("/api/ventas"), VentaResponse[].class);
    assertEquals(HttpStatus.OK, listing.getStatusCode());
    assertEquals(1, listing.getBody().length);

    VentaRequest updatedRequest =
        new VentaRequest(4, new BigDecimal("40.00"), LocalDateTime.now(), otherProduct.id());
    ResponseEntity<VentaResponse> update =
        client()
            .exchange(
                url("/api/ventas/" + created.id()),
                HttpMethod.PUT,
                new HttpEntity<>(updatedRequest),
                VentaResponse.class);
    assertEquals(HttpStatus.OK, update.getStatusCode());
    assertEquals(5, getProduct(product.id()).cantidadStock());
    assertEquals(2, getProduct(otherProduct.id()).cantidadStock());

    ResponseEntity<ApiError> overselling =
        client()
            .postForEntity(
                url("/api/ventas"),
                new VentaRequest(
                    3, new BigDecimal("30.00"), LocalDateTime.now(), otherProduct.id()),
                ApiError.class);
    assertEquals(HttpStatus.CONFLICT, overselling.getStatusCode());
    assertEquals(2, getProduct(otherProduct.id()).cantidadStock());

    ResponseEntity<ApiError> productInUse =
        client()
            .exchange(
                url("/api/productos/" + otherProduct.id()),
                HttpMethod.DELETE,
                HttpEntity.EMPTY,
                ApiError.class);
    assertEquals(HttpStatus.CONFLICT, productInUse.getStatusCode());

    ResponseEntity<Void> deletion =
        client().exchange(
            url("/api/ventas/" + created.id()), HttpMethod.DELETE, HttpEntity.EMPTY, Void.class);
    assertEquals(HttpStatus.NO_CONTENT, deletion.getStatusCode());
    assertEquals(5, getProduct(product.id()).cantidadStock());
    assertEquals(6, getProduct(otherProduct.id()).cantidadStock());
    assertEquals(
        HttpStatus.NOT_FOUND,
        client()
            .getForEntity(url("/api/ventas/" + created.id()), ApiError.class)
            .getStatusCode());
  }

  private ProductoResponse createProduct(String name, int stock) {
    ResponseEntity<ProductoResponse> response =
        client()
            .postForEntity(
                url("/api/productos"),
                new ProductoRequest(name, "Abarrotes", 10.0, stock),
                ProductoResponse.class);
    assertEquals(HttpStatus.CREATED, response.getStatusCode());
    return response.getBody();
  }

  private ProductoResponse getProduct(Long id) {
    return client().getForObject(url("/api/productos/" + id), ProductoResponse.class);
  }

  private TestRestTemplate client() {
    return restTemplate.withBasicAuth("api-test", "api-test-password");
  }

  private String url(String path) {
    return "http://localhost:" + port + path;
  }
}
