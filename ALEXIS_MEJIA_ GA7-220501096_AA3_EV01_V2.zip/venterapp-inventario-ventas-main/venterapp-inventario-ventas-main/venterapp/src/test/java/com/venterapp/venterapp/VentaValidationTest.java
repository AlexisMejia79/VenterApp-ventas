package com.venterapp.venterapp;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.venterapp.entity.Producto;
import com.venterapp.entity.Venta;
import jakarta.validation.Validation;
import jakarta.validation.ValidatorFactory;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

/** Verifica las restricciones de validacion de la entidad Venta. */
class VentaValidationTest {

  @Test
  void rejectsSaleWithoutDate() {
    Venta venta =
        new Venta(1, BigDecimal.ONE, null, new Producto("Producto", "Categoria", 1.0, 0));

    try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
      var violations = validatorFactory.getValidator().validate(venta);

      assertTrue(
          violations.stream()
              .anyMatch(violation -> violation.getPropertyPath().toString().equals("fechaVenta")));
    }
  }
}
