package com.venterapp.venterapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/** Pruebas de integración básicas del contexto Spring de VenterApp. */
@SpringBootTest(
    properties = {
      "spring.datasource.url=jdbc:h2:mem:venterapp;DB_CLOSE_DELAY=-1",
      "spring.datasource.driver-class-name=org.h2.Driver",
      "spring.datasource.username=sa",
      "spring.datasource.password=",
      "spring.jpa.hibernate.ddl-auto=create-drop",
      "spring.jpa.show-sql=false"
    })
class VenterappApplicationTests {

  @Test
  void contextLoads() {}

}
