package com.venterapp.exception;

import com.venterapp.dto.ApiError;
import java.time.Instant;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/** Convierte errores de negocio y persistencia en respuestas HTTP claras. */
@RestControllerAdvice
public class ApiExceptionHandler {

  @ExceptionHandler(ResourceNotFoundException.class)
  public ResponseEntity<ApiError> handleNotFound(ResourceNotFoundException exception) {
    return error(HttpStatus.NOT_FOUND, exception.getMessage());
  }

  @ExceptionHandler(InsufficientStockException.class)
  public ResponseEntity<ApiError> handleInsufficientStock(InsufficientStockException exception) {
    return error(HttpStatus.CONFLICT, exception.getMessage());
  }

  @ExceptionHandler(ResourceConflictException.class)
  public ResponseEntity<ApiError> handleConflict(ResourceConflictException exception) {
    return error(HttpStatus.CONFLICT, exception.getMessage());
  }

  @ExceptionHandler(DataIntegrityViolationException.class)
  public ResponseEntity<ApiError> handleIntegrityViolation(
      DataIntegrityViolationException exception) {
    return error(
        HttpStatus.CONFLICT,
        "La operacion no se puede completar porque el recurso tiene datos relacionados.");
  }

  private ResponseEntity<ApiError> error(HttpStatus status, String message) {
    ApiError body =
        new ApiError(Instant.now(), status.value(), status.getReasonPhrase(), message);
    return ResponseEntity.status(status).body(body);
  }
}
