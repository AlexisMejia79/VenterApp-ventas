package com.venterapp.service;

import com.venterapp.dto.VentaRequest;
import com.venterapp.dto.VentaResponse;
import com.venterapp.entity.Producto;
import com.venterapp.entity.Venta;
import com.venterapp.exception.InsufficientStockException;
import com.venterapp.exception.ResourceConflictException;
import com.venterapp.exception.ResourceNotFoundException;
import com.venterapp.repository.ProductoRepository;
import com.venterapp.repository.VentaRepository;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Mantiene las ventas y ajusta el stock en una misma transaccion. */
@Service
@Transactional
public class VentaService {

  private final VentaRepository ventaRepository;
  private final ProductoRepository productoRepository;

  public VentaService(VentaRepository ventaRepository, ProductoRepository productoRepository) {
    this.ventaRepository = ventaRepository;
    this.productoRepository = productoRepository;
  }

  @Transactional(readOnly = true)
  public List<VentaResponse> listar() {
    return ventaRepository.findAll().stream().map(VentaService::respuesta).toList();
  }

  @Transactional(readOnly = true)
  public VentaResponse buscar(Long id) {
    return respuesta(obtenerVenta(id));
  }

  public VentaResponse crear(VentaRequest request) {
    Producto producto = bloquearProducto(request.productoId());
    verificarStock(producto, request.cantidadVendida());
    producto.setCantidadStock(producto.getCantidadStock() - request.cantidadVendida());

    Venta venta =
        new Venta(
            request.cantidadVendida(), request.totalVenta(), request.fechaVenta(), producto);
    return respuesta(ventaRepository.save(venta));
  }

  public VentaResponse actualizar(Long id, VentaRequest request) {
    Venta venta = obtenerVentaBloqueada(id);
    Long productoAnteriorId = venta.getProducto().getId();
    Map<Long, Producto> productos =
        bloquearProductos(productoAnteriorId, request.productoId());
    Producto productoAnterior = productos.get(productoAnteriorId);
    Producto productoNuevo = productos.get(request.productoId());

    if (productoAnteriorId.equals(request.productoId())) {
      int stockDisponible = restaurarStock(productoAnterior, venta.getCantidadVendida());
      verificarStock(productoAnterior, request.cantidadVendida(), stockDisponible);
      productoAnterior.setCantidadStock(stockDisponible - request.cantidadVendida());
    } else {
      productoAnterior.setCantidadStock(
          restaurarStock(productoAnterior, venta.getCantidadVendida()));
      verificarStock(productoNuevo, request.cantidadVendida());
      productoNuevo.setCantidadStock(
          productoNuevo.getCantidadStock() - request.cantidadVendida());
    }

    venta.setCantidadVendida(request.cantidadVendida());
    venta.setTotalVenta(request.totalVenta());
    venta.setFechaVenta(request.fechaVenta());
    venta.setProducto(productoNuevo);
    return respuesta(ventaRepository.save(venta));
  }

  public void eliminar(Long id) {
    Venta venta = obtenerVentaBloqueada(id);
    Producto producto = bloquearProducto(venta.getProducto().getId());
    producto.setCantidadStock(restaurarStock(producto, venta.getCantidadVendida()));
    ventaRepository.delete(venta);
  }

  private Venta obtenerVenta(Long id) {
    return ventaRepository
        .findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("No existe la venta con id " + id + "."));
  }

  private Venta obtenerVentaBloqueada(Long id) {
    return ventaRepository
        .findByIdForUpdate(id)
        .orElseThrow(() -> new ResourceNotFoundException("No existe la venta con id " + id + "."));
  }

  private Producto bloquearProducto(Long id) {
    return productoRepository
        .findByIdForUpdate(id)
        .orElseThrow(
            () -> new ResourceNotFoundException("No existe el producto con id " + id + "."));
  }

  private Map<Long, Producto> bloquearProductos(Long... ids) {
    List<Long> idsOrdenados = Arrays.stream(ids).distinct().sorted().toList();
    Map<Long, Producto> productos = new HashMap<>();
    for (Long id : idsOrdenados) {
      productos.put(id, bloquearProducto(id));
    }
    return productos;
  }

  private void verificarStock(Producto producto, int cantidadSolicitada) {
    verificarStock(producto, cantidadSolicitada, producto.getCantidadStock());
  }

  private void verificarStock(Producto producto, int cantidadSolicitada, int stockDisponible) {
    if (cantidadSolicitada > stockDisponible) {
      throw new InsufficientStockException(
          "Stock insuficiente para el producto "
              + producto.getId()
              + ": disponible "
              + stockDisponible
              + ", solicitado "
              + cantidadSolicitada
              + ".");
    }
  }

  private int restaurarStock(Producto producto, int cantidad) {
    long stockRestaurado = (long) producto.getCantidadStock() + cantidad;
    if (stockRestaurado > Integer.MAX_VALUE) {
      throw new ResourceConflictException(
          "La operacion superaria el stock maximo permitido para el producto "
              + producto.getId()
              + ".");
    }
    return (int) stockRestaurado;
  }

  private static VentaResponse respuesta(Venta venta) {
    return new VentaResponse(
        venta.getId(),
        venta.getCantidadVendida(),
        venta.getTotalVenta(),
        venta.getFechaVenta(),
        venta.getProducto().getId(),
        venta.getProducto().getNombre());
  }
}
