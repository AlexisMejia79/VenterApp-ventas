package com.venterapp.repository;

import com.venterapp.entity.Venta;
import jakarta.persistence.LockModeType;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/** Operaciones de persistencia para las ventas registradas. */
public interface VentaRepository extends JpaRepository<Venta, Long> {

  @Lock(LockModeType.PESSIMISTIC_WRITE)
  @Query("select venta from Venta venta where venta.id = :id")
  Optional<Venta> findByIdForUpdate(@Param("id") Long id);

  boolean existsByProducto_Id(Long productoId);
}