package com.venterapp.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import java.time.LocalDate;

/**
 * Representa los administradores y vendedores registrados en VenterApp.
 *
 * @author José Alexis Mejía López
 * @version 1.0
 */
@Entity
@Table(name = "usuarios")
public class Usuario {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long idUsuario;

  @NotBlank(message = "El nombre es obligatorio")
  @Column(nullable = false, length = 100)
  private String nombre;

  @NotBlank(message = "El apellido es obligatorio")
  @Column(nullable = false, length = 100)
  private String apellido;

  @NotBlank(message = "La cédula es obligatoria")
  @Pattern(regexp = "^[0-9]+$", message = "La cédula solo debe contener números")
  @Column(nullable = false, unique = true, length = 20)
  private String cedula;

  @NotNull(message = "La fecha de nacimiento es obligatoria")
  @Past(message = "La fecha de nacimiento debe ser anterior a la fecha actual")
  @Column(nullable = false)
  private LocalDate fechaNacimiento;

  @NotBlank(message = "El correo es obligatorio")
  @Email(message = "El correo no tiene un formato válido")
  @Column(nullable = false, unique = true, length = 120)
  private String correo;

  @NotBlank(message = "La contraseña es obligatoria")
  @Column(nullable = false, length = 255)
  private String contrasena;

  @NotBlank(message = "El rol es obligatorio")
  @Column(nullable = false, length = 30)
  private String rol;

  public Usuario() {}

  public Long getIdUsuario() {
    return idUsuario;
  }

  public void setIdUsuario(Long idUsuario) {
    this.idUsuario = idUsuario;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getApellido() {
    return apellido;
  }

  public void setApellido(String apellido) {
    this.apellido = apellido;
  }

  public String getCedula() {
    return cedula;
  }

  public void setCedula(String cedula) {
    this.cedula = cedula;
  }

  public LocalDate getFechaNacimiento() {
    return fechaNacimiento;
  }

  public void setFechaNacimiento(LocalDate fechaNacimiento) {
    this.fechaNacimiento = fechaNacimiento;
  }

  public String getCorreo() {
    return correo;
  }

  public void setCorreo(String correo) {
    this.correo = correo;
  }

  public String getContrasena() {
    return contrasena;
  }

  public void setContrasena(String contrasena) {
    this.contrasena = contrasena;
  }

  public String getRol() {
    return rol;
  }

  public void setRol(String rol) {
    this.rol = rol;
  }
}