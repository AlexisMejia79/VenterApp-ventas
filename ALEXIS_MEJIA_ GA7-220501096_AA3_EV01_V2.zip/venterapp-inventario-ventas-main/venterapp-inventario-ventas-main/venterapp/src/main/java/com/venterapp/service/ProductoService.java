package com.venterapp.service;

import com.venterapp.dto.ProductoRequest;
import com.venterapp.dto.ProductoResponse;
import com.venterapp.entity.Producto;
import com.venterapp.exception.ResourceConflictException;
import com.venterapp.exception.ResourceNotFoundException;
import com.venterapp.repository.ProductoRepository;
import com.venterapp.repository.VentaRepository;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Coordina las operaciones de inventario y su persistencia. */
@Service
@Transactional
public class ProductoService {

  private final ProductoRepository productoRepository;
  private final VentaRepository ventaRepository;

  public ProductoService(
      ProductoRepository productoRepository, VentaRepository ventaRepository) {
    this.productoRepository = productoRepository;
    this.ventaRepository = ventaRepository;
  }

  @Transactional(readOnly = true)
  public List<ProductoResponse> listar() {
    return productoRepository.findAll().stream().map(ProductoService::respuesta).toList();
  }

  @Transactional(readOnly = true)
  public ProductoResponse buscar(Long id) {
    return respuesta(obtener(id));
  }

  public ProductoResponse crear(ProductoRequest request) {
    Producto producto =
        new Producto(
            request.nombre(), request.categoria(), request.precio(), request.cantidadStock());
    return respuesta(productoRepository.save(producto));
  }

  public ProductoResponse actualizar(Long id, ProductoRequest request) {
    Producto producto =
        productoRepository
            .findByIdForUpdate(id)
            .orElseThrow(
                () -> new ResourceNotFoundException("No existe el producto con id " + id + "."));
    producto.setNombre(request.nombre());
    producto.setCategoria(request.categoria());
    producto.setPrecio(request.precio());
    producto.setCantidadStock(request.cantidadStock());
    return respuesta(productoRepository.save(producto));
  }

  public void eliminar(Long id) {
    Producto producto =
        productoRepository
            .findByIdForUpdate(id)
            .orElseThrow(
                () -> new ResourceNotFoundException("No existe el producto con id " + id + "."));
    if (ventaRepository.existsByProducto_Id(id)) {
      throw new ResourceConflictException(
          "No se puede eliminar el producto porque tiene ventas relacionadas.");
    }
    productoRepository.delete(producto);
    productoRepository.flush();
  }

  private Producto obtener(Long id) {
    return productoRepository
        .findById(id)
        .orElseThrow(
            () -> new ResourceNotFoundException("No existe el producto con id " + id + "."));
  }

  private static ProductoResponse respuesta(Producto producto) {
    return new ProductoResponse(
        producto.getId(),
        producto.getNombre(),
        producto.getCategoria(),
        producto.getPrecio(),
        producto.getCantidadStock());
  }
}
