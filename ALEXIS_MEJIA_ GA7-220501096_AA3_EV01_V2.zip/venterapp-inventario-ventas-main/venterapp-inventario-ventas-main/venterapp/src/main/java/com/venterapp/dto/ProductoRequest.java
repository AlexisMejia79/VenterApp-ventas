package com.venterapp.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

/** Datos validados para crear o actualizar un producto. */
public record ProductoRequest(
    @NotBlank(message = "El nombre es obligatorio")
        @Size(max = 255, message = "El nombre no puede superar 255 caracteres")
        String nombre,
    @NotBlank(message = "La categoria es obligatoria")
        @Size(max = 255, message = "La categoria no puede superar 255 caracteres")
        String categoria,
    @NotNull(message = "El precio es obligatorio")
        @Positive(message = "El precio debe ser mayor que cero")
        Double precio,
    @NotNull(message = "La cantidad de stock es obligatoria")
        @PositiveOrZero(message = "El stock no puede ser negativo")
        Integer cantidadStock) {}
