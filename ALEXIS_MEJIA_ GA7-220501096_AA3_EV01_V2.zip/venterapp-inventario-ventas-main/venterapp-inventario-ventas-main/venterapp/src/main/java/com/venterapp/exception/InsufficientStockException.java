package com.venterapp.exception;

/** Indica que no hay existencias suficientes para registrar la venta. */
public class InsufficientStockException extends RuntimeException {

  public InsufficientStockException(String message) {
    super(message);
  }
}
