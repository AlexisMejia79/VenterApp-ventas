package com.venterapp.exception;

/** Indica que el recurso solicitado no existe. */
public class ResourceNotFoundException extends RuntimeException {

  public ResourceNotFoundException(String message) {
    super(message);
  }
}
