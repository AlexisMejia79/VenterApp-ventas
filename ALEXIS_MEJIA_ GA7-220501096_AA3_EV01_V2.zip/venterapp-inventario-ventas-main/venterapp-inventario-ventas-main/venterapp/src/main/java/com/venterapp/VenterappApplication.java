package com.venterapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal del sistema VenterApp.
 * Sistema de gestión de ventas e inventario para vendedores ambulantes colombianos.
 *
 * @author José Alexis Mejía López
 * @version 1.0
 */
@SpringBootApplication
public class VenterappApplication {

  public static void main(String[] args) {
    SpringApplication.run(VenterappApplication.class, args);
  }
}