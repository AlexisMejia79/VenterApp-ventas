package com.venterapp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

/**
 * Producto disponible para la venta y controlado por el inventario.
 */
@Entity
@Table(name = "productos")
public class Producto {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @NotBlank(message = "El nombre es obligatorio")
  @Column(nullable = false)
  private String nombre;

  @NotBlank(message = "La categoria es obligatoria")
  @Column(nullable = false)
  private String categoria;

  @NotNull(message = "El precio es obligatorio")
  @Positive(message = "El precio debe ser mayor que cero")
  @Column(nullable = false)
  private Double precio;

  @NotNull(message = "La cantidad de stock es obligatoria")
  @PositiveOrZero(message = "El stock no puede ser negativo")
  @Column(nullable = false)
  private Integer cantidadStock;

  public Producto() {}

  public Producto(String nombre, String categoria, Double precio, Integer cantidadStock) {
    this.nombre = nombre;
    this.categoria = categoria;
    this.precio = precio;
    this.cantidadStock = cantidadStock;
  }

  public Long getId() {
    return id;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getCategoria() {
    return categoria;
  }

  public void setCategoria(String categoria) {
    this.categoria = categoria;
  }

  public Double getPrecio() {
    return precio;
  }

  public void setPrecio(Double precio) {
    this.precio = precio;
  }

  public Integer getCantidadStock() {
    return cantidadStock;
  }

  public void setCantidadStock(Integer cantidadStock) {
    this.cantidadStock = cantidadStock;
  }
}