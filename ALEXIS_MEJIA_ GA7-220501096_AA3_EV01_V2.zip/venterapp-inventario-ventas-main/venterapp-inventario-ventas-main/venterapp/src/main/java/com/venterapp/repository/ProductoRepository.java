package com.venterapp.repository;

import com.venterapp.entity.Producto;
import jakarta.persistence.LockModeType;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/** Operaciones de persistencia para los productos del inventario. */
public interface ProductoRepository extends JpaRepository<Producto, Long> {

  @Lock(LockModeType.PESSIMISTIC_WRITE)
  @Query("select producto from Producto producto where producto.id = :id")
  Optional<Producto> findByIdForUpdate(@Param("id") Long id);
}