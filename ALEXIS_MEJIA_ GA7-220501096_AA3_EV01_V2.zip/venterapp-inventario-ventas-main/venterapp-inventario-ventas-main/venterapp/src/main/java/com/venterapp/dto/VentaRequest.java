package com.venterapp.dto;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Datos validados para registrar o modificar una venta. */
public record VentaRequest(
    @NotNull(message = "La cantidad vendida es obligatoria")
        @Positive(message = "La cantidad vendida debe ser mayor que cero")
        Integer cantidadVendida,
    @NotNull(message = "El total de la venta es obligatorio")
        @Positive(message = "El total de la venta debe ser mayor que cero")
        @Digits(
            integer = 8,
            fraction = 2,
            message = "El total admite hasta 8 enteros y 2 decimales")
        BigDecimal totalVenta,
    @NotNull(message = "La fecha de venta es obligatoria") LocalDateTime fechaVenta,
    @NotNull(message = "Debe indicar el producto asociado a la venta") Long productoId) {}
