package com.venterapp.exception;

/** Indica que una operacion entra en conflicto con el estado del recurso. */
public class ResourceConflictException extends RuntimeException {

  public ResourceConflictException(String message) {
    super(message);
  }
}
