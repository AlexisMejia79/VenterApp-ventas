package com.venterapp.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Representacion publica de una venta y del producto asociado. */
public record VentaResponse(
    Long id,
    Integer cantidadVendida,
    BigDecimal totalVenta,
    LocalDateTime fechaVenta,
    Long productoId,
    String productoNombre) {}
