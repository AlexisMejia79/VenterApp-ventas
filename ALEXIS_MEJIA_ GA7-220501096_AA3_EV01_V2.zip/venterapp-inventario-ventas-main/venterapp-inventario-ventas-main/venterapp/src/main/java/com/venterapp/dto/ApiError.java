package com.venterapp.dto;

import java.time.Instant;

/** Respuesta uniforme para errores de la API. */
public record ApiError(Instant timestamp, int status, String error, String message) {}
