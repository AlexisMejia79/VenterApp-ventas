package com.venterapp.controller;

import com.venterapp.dto.VentaRequest;
import com.venterapp.dto.VentaResponse;
import com.venterapp.service.VentaService;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Endpoints REST para consultar y administrar ventas. */
@RestController
@RequestMapping("/api/ventas")
public class VentaController {

  private final VentaService ventaService;

  public VentaController(VentaService ventaService) {
    this.ventaService = ventaService;
  }

  @GetMapping
  public List<VentaResponse> listar() {
    return ventaService.listar();
  }

  @GetMapping("/{id}")
  public VentaResponse buscar(@PathVariable Long id) {
    return ventaService.buscar(id);
  }

  @PostMapping
  public ResponseEntity<VentaResponse> crear(@Valid @RequestBody VentaRequest request) {
    VentaResponse creada = ventaService.crear(request);
    return ResponseEntity.created(URI.create("/api/ventas/" + creada.id())).body(creada);
  }

  @PutMapping("/{id}")
  public VentaResponse actualizar(
      @PathVariable Long id, @Valid @RequestBody VentaRequest request) {
    return ventaService.actualizar(id, request);
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<Void> eliminar(@PathVariable Long id) {
    ventaService.eliminar(id);
    return ResponseEntity.noContent().build();
  }
}
