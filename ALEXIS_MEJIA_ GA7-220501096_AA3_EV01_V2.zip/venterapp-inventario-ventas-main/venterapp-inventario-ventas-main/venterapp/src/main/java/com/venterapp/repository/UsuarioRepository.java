package com.venterapp.repository;

import com.venterapp.entity.Usuario;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/** Operaciones de persistencia y consulta para los usuarios registrados. */
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
  boolean existsByCedula(String cedula);

  boolean existsByCorreo(String correo);

  Optional<Usuario> findByCorreo(String correo);
}