package com.venterapp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Venta registrada para un producto del inventario.
 */
@Entity
@Table(name = "ventas")
public class Venta {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @NotNull(message = "La cantidad vendida es obligatoria")
  @Positive(message = "La cantidad vendida debe ser mayor que cero")
  @Column(nullable = false)
  private Integer cantidadVendida;

  @NotNull(message = "El total de la venta es obligatorio")
  @Positive(message = "El total de la venta debe ser mayor que cero")
  @Column(nullable = false, precision = 10, scale = 2)
  private BigDecimal totalVenta;

  @NotNull(message = "La fecha de venta es obligatoria")
  @Column(nullable = false)
  private LocalDateTime fechaVenta;

  @NotNull(message = "Debe indicar el producto asociado a la venta")
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "producto_id", nullable = false)
  private Producto producto;

  public Venta() {}

  public Venta(
      Integer cantidadVendida, BigDecimal totalVenta, LocalDateTime fechaVenta, Producto producto) {
    this.cantidadVendida = cantidadVendida;
    this.totalVenta = totalVenta;
    this.fechaVenta = fechaVenta;
    this.producto = producto;
  }

  public Long getId() {
    return id;
  }

  public Integer getCantidadVendida() {
    return cantidadVendida;
  }

  public void setCantidadVendida(Integer cantidadVendida) {
    this.cantidadVendida = cantidadVendida;
  }

  public BigDecimal getTotalVenta() {
    return totalVenta;
  }

  public void setTotalVenta(BigDecimal totalVenta) {
    this.totalVenta = totalVenta;
  }

  public LocalDateTime getFechaVenta() {
    return fechaVenta;
  }

  public void setFechaVenta(LocalDateTime fechaVenta) {
    this.fechaVenta = fechaVenta;
  }

  public Producto getProducto() {
    return producto;
  }

  public void setProducto(Producto producto) {
    this.producto = producto;
  }
}