package com.venterapp.dto;

/** Representacion publica de un producto. */
public record ProductoResponse(
    Long id, String nombre, String categoria, Double precio, Integer cantidadStock) {}
