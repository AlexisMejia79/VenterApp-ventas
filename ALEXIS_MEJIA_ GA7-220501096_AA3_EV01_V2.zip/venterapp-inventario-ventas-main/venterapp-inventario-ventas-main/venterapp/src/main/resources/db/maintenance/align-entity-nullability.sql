-- Alinea las columnas existentes con las restricciones nullable=false de JPA.
-- Ejecutar sobre venterapp_db despues de confirmar que no hay valores nulos.
ALTER TABLE productos
  MODIFY nombre VARCHAR(255) NOT NULL,
  MODIFY categoria VARCHAR(255) NOT NULL,
  MODIFY precio DOUBLE NOT NULL,
  MODIFY cantidad_stock INT NOT NULL;

ALTER TABLE ventas
  MODIFY cantidad_vendida INT NOT NULL,
  MODIFY fecha_venta DATETIME(6) NOT NULL,
  MODIFY producto_id BIGINT NOT NULL;
